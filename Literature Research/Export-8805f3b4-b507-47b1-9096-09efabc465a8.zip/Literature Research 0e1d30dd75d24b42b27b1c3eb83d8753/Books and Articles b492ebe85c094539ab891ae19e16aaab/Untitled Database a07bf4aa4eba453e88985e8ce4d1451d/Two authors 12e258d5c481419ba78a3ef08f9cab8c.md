# Two authors

Text: [author last name] & [author last name] [publication year] [publication abbreviated title].pdf