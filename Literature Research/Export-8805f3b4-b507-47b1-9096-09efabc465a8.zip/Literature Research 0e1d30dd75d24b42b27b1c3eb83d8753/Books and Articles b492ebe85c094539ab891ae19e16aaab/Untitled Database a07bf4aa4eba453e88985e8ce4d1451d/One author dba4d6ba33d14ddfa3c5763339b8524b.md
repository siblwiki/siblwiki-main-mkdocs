# One author

Text: [author last name] [publication year] [publication abbreviated title].pdf